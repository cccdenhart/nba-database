
// represents the different possible types of objects (instances) in the database
public enum ObjectType {
  TEAM, PLAYER, GAME, PLAYER_STATS
}
